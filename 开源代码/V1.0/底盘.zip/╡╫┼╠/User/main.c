#include "stm32f4xx.h"                  // Device header
#include "stm32f4xx_conf.h"
#include <stdio.h>
#include "RM_C.h"

int main()
{
 	Warming_Init();//报警初始化
	LED_BON();//蓝灯点亮表示代码在运行
	Delay_s(2);//延时,等待校准和模块启动
	RefereeSystem_Init();//裁判系统数据接收初始化
	LinkCheck_Init();//连接检测初始化
	Ultra_CAP_Init();//超电初始化
	CloseLoopControl_Init();//闭环控制初始化
	while(1)
	{
		CToC_SlaveSendRefereeSystemData();//向主机发送裁判系统数据
		Delay_us(2000);
	}
}
