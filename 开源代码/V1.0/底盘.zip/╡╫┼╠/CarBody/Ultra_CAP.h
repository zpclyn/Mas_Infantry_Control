#ifndef __ULTRA_CAP_H
#define __ULTRA_CAP_H

void Ultra_CAP_Init(void);//超电初始化
uint8_t Ultra_CAP_SetPower(float PowerLimit);//超电设置功率上限

#endif
