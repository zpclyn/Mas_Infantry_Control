#ifndef __UI_H
#define __UI_H

void UI_Init(void);//UI初始化
void UI_Updata(void);//UI更新
void UI_RemoteNoCheck(void);//UI显示遥控器未连接

#endif
