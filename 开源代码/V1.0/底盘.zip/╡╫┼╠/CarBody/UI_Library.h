#ifndef __UI_LIBRARY_H
#define __UI_LIBRARY_H

/*==========Shift文本==========*/
void _ui_init_default_Ungroup_0(void);
void _ui_update_default_Ungroup_0(void);
void _ui_remove_default_Ungroup_0(void);

/*==========Ctrl文本==========*/
void _ui_init_default_Ungroup_1(void);
void _ui_update_default_Ungroup_1(void);
void _ui_remove_default_Ungroup_1(void);

/*==========指示灯==========*/
void _ui_init_default_Ungroup_2(void);
void _ui_update_default_Ungroup_2_ERROR(void);
void _ui_update_default_Ungroup_2_NOCheck(void);
void _ui_update_default_Ungroup_2_Shift_Open(void);
void _ui_update_default_Ungroup_2_Shift_Close(void);
void _ui_update_default_Ungroup_2_Ctrl_Open(void);
void _ui_update_default_Ungroup_2_Ctrl_Close(void);

#endif
