#include "stm32f4xx.h"                  // Device header
#include "stm32f4xx_conf.h"
#include "UI_Library.h"
#include "Remote.h"
#include "CloseLoopControl.h"
#include "Delay.h"
#include "RefereeSystem.h"

/*
 *函数简介:UI初始化
 *参数说明:无
 *返回类型:无
 *备注:无
 */
void UI_Init(void)
{
	_ui_init_default_Ungroup_1();
	Delay_ms(100);
	_ui_init_default_Ungroup_0();
	Delay_ms(100);
	_ui_init_default_Ungroup_2();
	Delay_ms(100);
	_ui_init_default_Ungroup_1();
	Delay_ms(100);
}

/*
 *函数简介:UI更新
 *参数说明:无
 *返回类型:无
 *备注:无
 */
void UI_Updata(void)
{
	static uint8_t Count=0;
	Count=(Count+1)%2;//每次更新一个,循环更新提高效率
	
	if(CloseLoopControl_ErrorFlag==1)//遥控器未连接,所有指示灯变绿
	{
		CloseLoopControl_ErrorFlag=0;
		_ui_update_default_Ungroup_2_NOCheck();
	}
	else
	{
		if(Count==0)//更新Shift
		{
			if(Remote_RxData.Remote_KeyPush_Shift==1)_ui_update_default_Ungroup_2_Shift_Open();
			else _ui_update_default_Ungroup_2_Shift_Close();
		}
		else//更新Ctrl
		{
			if(Remote_RxData.Remote_KeyPush_Ctrl==1)_ui_update_default_Ungroup_2_Ctrl_Open();
			else _ui_update_default_Ungroup_2_Ctrl_Close();
		}
	}
}

/*
 *函数简介:UI显示遥控器未连接
 *参数说明:无
 *返回类型:无
 *备注:所有指示灯变绿
 */
void UI_RemoteNoCheck(void)
{
	if(CloseLoopControl_ErrorFlag==1)CloseLoopControl_ErrorFlag=0;
	_ui_update_default_Ungroup_2_NOCheck();
}
