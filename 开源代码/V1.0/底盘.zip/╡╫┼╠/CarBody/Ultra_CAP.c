#include "stm32f4xx.h"                  // Device header
#include "stm32f4xx_conf.h"

/*
 *函数简介:超电使能
 *参数说明:0-停机,1-运行(负载关),2-运行(负载开)
 *返回类型:1-发送成功,0-发送失败
 *备注:标识符0x600,数据长度4字节
 */
uint8_t Ultra_CAP_Enable(uint8_t EnableFlag)
{
	CanTxMsg TxMessage;
	TxMessage.StdId=0x600;//ID标准标识符0x600
	TxMessage.RTR=CAN_RTR_Data;//数据帧
	TxMessage.IDE=CAN_Id_Standard;//标准格式
	TxMessage.DLC=0x04;//4字节数据段
	TxMessage.Data[0]=0;
	TxMessage.Data[1]=EnableFlag;
	TxMessage.Data[2]=0;
	TxMessage.Data[3]=0;
	
	uint8_t mbox=CAN_Transmit(CAN1,&TxMessage);//发送数据并获取邮箱号
	uint16_t i=0;
	while((CAN_TransmitStatus(CAN1,mbox)==CAN_TxStatus_Failed)&&(i<0xFFF))i++;//等待发送结束
	if(i>=0xFFF)return 0;//发送失败
	return 1;//发送成功
}

/*
 *函数简介:超电设置电压上限
 *参数说明:电压
 *返回类型:1-发送成功,0-发送失败
 *备注:标识符0x602,数据长度4字节,默认存入EEPROM
 *备注:设定值=电压*100
 */
uint8_t Ultra_CAP_SetVoltage(float Voltage)
{
	uint16_t SetVoltage=(uint16_t)((int16_t)(Voltage*100.0f));
	CanTxMsg TxMessage;
	TxMessage.StdId=0x602;//ID标准标识符0x602
	TxMessage.RTR=CAN_RTR_Data;//数据帧
	TxMessage.IDE=CAN_Id_Standard;//标准格式
	TxMessage.DLC=0x04;//4字节数据段
	TxMessage.Data[0]=(uint8_t)(SetVoltage>>8);
	TxMessage.Data[1]=(uint8_t)(SetVoltage & 0x00FF);
	TxMessage.Data[2]=0;
	TxMessage.Data[3]=0x01;
	
	uint8_t mbox=CAN_Transmit(CAN1,&TxMessage);//发送数据并获取邮箱号
	uint16_t i=0;
	while((CAN_TransmitStatus(CAN1,mbox)==CAN_TxStatus_Failed)&&(i<0xFFF))i++;//等待发送结束
	if(i>=0xFFF)return 0;//发送失败
	return 1;//发送成功
}

/*
 *函数简介:超电设置电流上限
 *参数说明:无
 *返回类型:1-发送成功,0-发送失败
 *备注:标识符0x603,数据长度4字节,默认存入EEPROM
 *备注:设定值=电流*100
 */
uint8_t Ultra_CAP_SetCurrent(float Current)
{
	uint16_t SetCurrent=(uint16_t)((int16_t)(Current*100.0f));
	CanTxMsg TxMessage;
	TxMessage.StdId=0x603;//低位ID标准标识符0x603
	TxMessage.RTR=CAN_RTR_Data;//数据帧
	TxMessage.IDE=CAN_Id_Standard;//标准格式
	TxMessage.DLC=0x04;//4字节数据段
	TxMessage.Data[0]=(uint8_t)(SetCurrent>>8);
	TxMessage.Data[1]=(uint8_t)(SetCurrent & 0x00FF);
	TxMessage.Data[2]=0;
	TxMessage.Data[3]=0x01;
	
	uint8_t mbox=CAN_Transmit(CAN1,&TxMessage);//发送数据并获取邮箱号
	uint16_t i=0;
	while((CAN_TransmitStatus(CAN1,mbox)==CAN_TxStatus_Failed)&&(i<0xFFF))i++;//等待发送结束
	if(i>=0xFFF)return 0;//发送失败
	return 1;//发送成功
}

/*
 *函数简介:超电设置功率上限
 *参数说明:无
 *返回类型:1-发送成功,0-发送失败
 *备注:标识符0x601,数据长度4字节
 *备注:设定值=功率*100
 */
uint8_t Ultra_CAP_SetPower(float PowerLimit)
{	
	uint16_t SetPower=(uint16_t)((int16_t)(PowerLimit*100.0f));
	CanTxMsg TxMessage;
	TxMessage.StdId=0x601;//低位ID标准标识符0x601
	TxMessage.RTR=CAN_RTR_Data;//数据帧
	TxMessage.IDE=CAN_Id_Standard;//标准格式
	TxMessage.DLC=0x04;//4字节数据段
	TxMessage.Data[0]=(uint8_t)(SetPower>>8);
	TxMessage.Data[1]=(uint8_t)(SetPower & 0x00FF);
	TxMessage.Data[2]=0;
	TxMessage.Data[3]=0;
	
	uint8_t mbox=CAN_Transmit(CAN1,&TxMessage);//发送数据并获取邮箱号
	uint16_t i=0;
	while((CAN_TransmitStatus(CAN1,mbox)==CAN_TxStatus_Failed)&&(i<0xFFF))i++;//等待发送结束
	if(i>=0xFFF)return 0;//发送失败
	return 1;//发送成功
}

/*
 *函数简介:超电初始化
 *参数说明:无
 *返回类型:无
 *备注:默认设定电压23V,电流8A,功率150W
 */
void Ultra_CAP_Init(void)
{
	Ultra_CAP_SetVoltage(23.0f);
	Ultra_CAP_SetCurrent(8.0f);
	Ultra_CAP_Enable(2);
	Ultra_CAP_SetPower(150.0f);
}
