#include "stm32f4xx.h"                  // Device header
#include "stm32f4xx_conf.h"
#include "UI_Base.h"
#include <string.h>
#include "UART.h"

/*==========Shift文本==========*/
ui_string_frame_t ui_default_Ungroup_0;
ui_interface_string_t* ui_default_Ungroup_Text_Shift=&ui_default_Ungroup_0.option;

void _ui_init_default_Ungroup_0(void)
{
    ui_default_Ungroup_0.option.figure_name[0]=0;
    ui_default_Ungroup_0.option.figure_name[1]=0;
    ui_default_Ungroup_0.option.figure_name[2]=0;
    ui_default_Ungroup_0.option.operate_tpye=1;
    ui_default_Ungroup_0.option.figure_tpye=7;
    ui_default_Ungroup_0.option.layer=0;
    ui_default_Ungroup_0.option.font_size=30;
    ui_default_Ungroup_0.option.start_x=75;
    ui_default_Ungroup_0.option.start_y=850;
    ui_default_Ungroup_0.option.color=2;
    ui_default_Ungroup_0.option.str_length=5;
    ui_default_Ungroup_0.option.width=6;
    strcpy(ui_default_Ungroup_Text_Shift->string, "Shift");

    ui_proc_string_frame(&ui_default_Ungroup_0);
	UART1_SendArray((uint8_t *)&ui_default_Ungroup_0,sizeof(ui_default_Ungroup_0));
}

void _ui_update_default_Ungroup_0(void)
{
    ui_default_Ungroup_0.option.operate_tpye=2;

    ui_proc_string_frame(&ui_default_Ungroup_0);
	UART1_SendArray((uint8_t *)&ui_default_Ungroup_0,sizeof(ui_default_Ungroup_0));
}

void _ui_remove_default_Ungroup_0(void)
{
    ui_default_Ungroup_0.option.operate_tpye=3;

    ui_proc_string_frame(&ui_default_Ungroup_0);
	UART1_SendArray((uint8_t *)&ui_default_Ungroup_0,sizeof(ui_default_Ungroup_0));
}

/*==========Ctrl文本==========*/
ui_string_frame_t ui_default_Ungroup_1;
ui_interface_string_t* ui_default_Ungroup_Text_Ctrl=&ui_default_Ungroup_1.option;

void _ui_init_default_Ungroup_1(void)
{
    ui_default_Ungroup_1.option.figure_name[0]=0;
    ui_default_Ungroup_1.option.figure_name[1]=0;
    ui_default_Ungroup_1.option.figure_name[2]=1;
    ui_default_Ungroup_1.option.operate_tpye=1;
    ui_default_Ungroup_1.option.figure_tpye=7;
    ui_default_Ungroup_1.option.layer=0;
    ui_default_Ungroup_1.option.font_size=30;
    ui_default_Ungroup_1.option.start_x=75;
    ui_default_Ungroup_1.option.start_y=750;
    ui_default_Ungroup_1.option.color=2;
    ui_default_Ungroup_1.option.str_length=4;
    ui_default_Ungroup_1.option.width=6;
    strcpy(ui_default_Ungroup_Text_Ctrl->string,"Ctrl");

    ui_proc_string_frame(&ui_default_Ungroup_1);
	UART1_SendArray((uint8_t *)&ui_default_Ungroup_1,sizeof(ui_default_Ungroup_1));
}

void _ui_update_default_Ungroup_1(void)
{
    ui_default_Ungroup_1.option.operate_tpye=2;

    ui_proc_string_frame(&ui_default_Ungroup_1);
	UART1_SendArray((uint8_t *)&ui_default_Ungroup_1,sizeof(ui_default_Ungroup_1));
}

void _ui_remove_default_Ungroup_1(void)
{
    ui_default_Ungroup_1.option.operate_tpye=3;

    ui_proc_string_frame(&ui_default_Ungroup_1);
	UART1_SendArray((uint8_t *)&ui_default_Ungroup_1,sizeof(ui_default_Ungroup_1));
}

/*==========指示灯==========*/
ui_2_frame_t ui_default_Ungroup_2;
ui_interface_round_t *ui_default_Ungroup_Round_Shift=(ui_interface_round_t *)&(ui_default_Ungroup_2.data[0]);
ui_interface_round_t *ui_default_Ungroup_Round_Ctrl=(ui_interface_round_t *)&(ui_default_Ungroup_2.data[1]);

void _ui_init_default_Ungroup_2(void)
{
    for(int i=0;i<2;i++)
	{
        ui_default_Ungroup_2.data[i].figure_name[0]=0;
        ui_default_Ungroup_2.data[i].figure_name[1]=0;
        ui_default_Ungroup_2.data[i].figure_name[2]=i+2;
        ui_default_Ungroup_2.data[i].operate_tpye=1;
    }

    ui_default_Ungroup_Round_Shift->figure_tpye=2;
    ui_default_Ungroup_Round_Shift->layer=0;
    ui_default_Ungroup_Round_Shift->details_r=20;
    ui_default_Ungroup_Round_Shift->start_x=250;
    ui_default_Ungroup_Round_Shift->start_y=835;
    ui_default_Ungroup_Round_Shift->color=2;
    ui_default_Ungroup_Round_Shift->width=2;

    ui_default_Ungroup_Round_Ctrl->figure_tpye=2;
    ui_default_Ungroup_Round_Ctrl->layer=0;
    ui_default_Ungroup_Round_Ctrl->details_r=20;
    ui_default_Ungroup_Round_Ctrl->start_x=250;
    ui_default_Ungroup_Round_Ctrl->start_y=735;
    ui_default_Ungroup_Round_Ctrl->color=2;
    ui_default_Ungroup_Round_Ctrl->width=2;

    ui_proc_2_frame(&ui_default_Ungroup_2);
	UART1_SendArray((uint8_t *)&ui_default_Ungroup_2,sizeof(ui_default_Ungroup_2));
}

void _ui_update_default_Ungroup_2_ERROR(void)
{
	ui_default_Ungroup_2.data[0].operate_tpye=2;
	ui_default_Ungroup_2.data[1].operate_tpye=2;
	
	ui_default_Ungroup_Round_Shift->details_r=10;
	ui_default_Ungroup_Round_Shift->start_x=240;
	ui_default_Ungroup_Round_Shift->start_y=825;
	ui_default_Ungroup_Round_Shift->color=0;
	ui_default_Ungroup_Round_Shift->width=20;

    ui_default_Ungroup_Round_Ctrl->details_r=10;
    ui_default_Ungroup_Round_Ctrl->start_x=240;
    ui_default_Ungroup_Round_Ctrl->start_y=725;
    ui_default_Ungroup_Round_Ctrl->color=0;
    ui_default_Ungroup_Round_Ctrl->width=20;
	
    ui_proc_2_frame(&ui_default_Ungroup_2);
	UART1_SendArray((uint8_t *)&ui_default_Ungroup_2,sizeof(ui_default_Ungroup_2));
}

void _ui_update_default_Ungroup_2_NOCheck(void)
{
	ui_default_Ungroup_2.data[0].operate_tpye=2;
	ui_default_Ungroup_2.data[1].operate_tpye=2;
	
    ui_default_Ungroup_Round_Shift->details_r=20;
    ui_default_Ungroup_Round_Shift->start_x=250;
    ui_default_Ungroup_Round_Shift->start_y=835;
    ui_default_Ungroup_Round_Shift->color=2;
    ui_default_Ungroup_Round_Shift->width=2;

    ui_default_Ungroup_Round_Ctrl->details_r=20;
    ui_default_Ungroup_Round_Ctrl->start_x=250;
    ui_default_Ungroup_Round_Ctrl->start_y=735;
    ui_default_Ungroup_Round_Ctrl->color=2;
    ui_default_Ungroup_Round_Ctrl->width=2;
	
    ui_proc_2_frame(&ui_default_Ungroup_2);
	UART1_SendArray((uint8_t *)&ui_default_Ungroup_2,sizeof(ui_default_Ungroup_2));
}

void _ui_update_default_Ungroup_2_Shift_Open(void)
{
	ui_default_Ungroup_2.data[0].operate_tpye=2;
	ui_default_Ungroup_2.data[1].operate_tpye=0;
	
    ui_default_Ungroup_Round_Shift->details_r=10;
    ui_default_Ungroup_Round_Shift->start_x=250;
    ui_default_Ungroup_Round_Shift->start_y=835;
    ui_default_Ungroup_Round_Shift->color=2;
    ui_default_Ungroup_Round_Shift->width=20;
	
    ui_proc_2_frame(&ui_default_Ungroup_2);
	UART1_SendArray((uint8_t *)&ui_default_Ungroup_2,sizeof(ui_default_Ungroup_2));
}

void _ui_update_default_Ungroup_2_Shift_Close(void)
{
	ui_default_Ungroup_2.data[0].operate_tpye=2;
	ui_default_Ungroup_2.data[1].operate_tpye=0;
	
    ui_default_Ungroup_Round_Shift->details_r=20;
    ui_default_Ungroup_Round_Shift->start_x=250;
    ui_default_Ungroup_Round_Shift->start_y=835;
    ui_default_Ungroup_Round_Shift->color=2;
    ui_default_Ungroup_Round_Shift->width=2;
	
    ui_proc_2_frame(&ui_default_Ungroup_2);
	UART1_SendArray((uint8_t *)&ui_default_Ungroup_2,sizeof(ui_default_Ungroup_2));
}

void _ui_update_default_Ungroup_2_Ctrl_Open(void)
{
	ui_default_Ungroup_2.data[0].operate_tpye=0;
	ui_default_Ungroup_2.data[1].operate_tpye=2;
	
    ui_default_Ungroup_Round_Ctrl->details_r=10;
    ui_default_Ungroup_Round_Ctrl->start_x=250;
    ui_default_Ungroup_Round_Ctrl->start_y=735;
    ui_default_Ungroup_Round_Ctrl->color=2;
    ui_default_Ungroup_Round_Ctrl->width=20;
	
    ui_proc_2_frame(&ui_default_Ungroup_2);
	UART1_SendArray((uint8_t *)&ui_default_Ungroup_2,sizeof(ui_default_Ungroup_2));
}

void _ui_update_default_Ungroup_2_Ctrl_Close(void)
{
	ui_default_Ungroup_2.data[0].operate_tpye=0;
	ui_default_Ungroup_2.data[1].operate_tpye=2;
	
    ui_default_Ungroup_Round_Ctrl->details_r=20;
    ui_default_Ungroup_Round_Ctrl->start_x=250;
    ui_default_Ungroup_Round_Ctrl->start_y=735;
    ui_default_Ungroup_Round_Ctrl->color=2;
    ui_default_Ungroup_Round_Ctrl->width=2;
	
    ui_proc_2_frame(&ui_default_Ungroup_2);
	UART1_SendArray((uint8_t *)&ui_default_Ungroup_2,sizeof(ui_default_Ungroup_2));
}
