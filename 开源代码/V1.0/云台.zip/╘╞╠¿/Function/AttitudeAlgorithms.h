#ifndef __ATTITUDEALGORITHMS_H
#define __ATTITUDEALGORITHMS_H

extern float AttitudeAlgorithms_RadYaw,AttitudeAlgorithms_RadPitch,AttitudeAlgorithms_RadRoll;//弧度制角度
extern float AttitudeAlgorithms_DegYaw,AttitudeAlgorithms_DegPitch,AttitudeAlgorithms_DegRoll;//角度制角度

void AttitudeAlgorithms_Init(void);//姿态解算初始化

#endif
