#ifndef __CLOSELOOPCONTROL_H
#define __CLOSELOOPCONTROL_H

void CloseLoopControl_Init(void);//闭环控制初始化

#endif
