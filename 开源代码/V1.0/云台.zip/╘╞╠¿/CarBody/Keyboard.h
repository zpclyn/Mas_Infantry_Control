#ifndef __KEYBOARD_H
#define __KEYBOARD_H

void Keyboard_Init(void);//键盘初始化
void Keyboard_DataProcess(uint8_t *Data);//键盘数据处理

#endif
