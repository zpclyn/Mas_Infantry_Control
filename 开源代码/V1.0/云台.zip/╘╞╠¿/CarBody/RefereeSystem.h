#ifndef __REFEREESYSTEM_H
#define __REFEREESYSTEM_H

extern uint8_t RefereeSystem_ShooterStatus;//裁判系统接收数据缓冲区

extern uint8_t RefereeSystem_ShooterOpenFlag;//发射机构上电标志位,1-发射机构正在上电,0-其他
extern uint16_t RefereeSystem_ShooterOpenCounter;//发射机构上电读秒等待设备启动
extern uint8_t RefereeSystem_Status;//图传链路连接状态

void RefereeSystem_Init(void);//裁判系统接收初始化

#endif
