#include "stm32f4xx.h"                  // Device header
#include "stm32f4xx_conf.h"
#include "UART.h"

float Visual_Yaw,Visual_Pitch;//视觉数据偏航角,视觉数据俯仰角
uint8_t Visual_RxHEXPacket[4],Visual_ReceiveFlag;//视觉数据接收缓冲区,视觉数据接收完成标志位

/*
 *函数简介:视觉初始化
 *参数说明:无
 *返回类型:无
 *备注:初始化UART2(USART1)
 */
void Visual_Init(void)
{
	UART2_Init();
}

/*
 *函数简介:UART2串口中断接收视觉数据
 *参数说明:无
 *返回类型:无
 *备注:无
 */
void USART1_IRQHandler(void)
{
	#define DataLength		4//有效数据位数
	
	static uint16_t UART2_RxData;
	static int RxHEXState=0;//定义静态变量用于接收模式的选择
	static int pRxHEXState=0;//定义静态变量用于充当计数器
	
	if(USART_GetITStatus(USART1,USART_IT_RXNE)==SET)//查询接收中断标志位
	{
		UART2_RxData=USART_ReceiveData(USART1);//将数据存入缓存区
		
		if(RxHEXState==0)//模式0-等待包头1(0x09)
		{
			if(UART2_RxData==0x09)//检测包头
				RxHEXState=1;//转入模式1
		}
		else if(RxHEXState==1)//模式1-等待包头2(0x14)
		{
			if(UART2_RxData==0x14)//检测包头
			{
				RxHEXState=2;//转入模式2
				pRxHEXState=0;//复位计数器
			}
			else
				RxHEXState=0;
		}
		else if(RxHEXState==2)//模式2-接收有效数据
		{
			Visual_RxHEXPacket[pRxHEXState]=UART2_RxData;//接收数据
			pRxHEXState++;
			
			if(pRxHEXState>=DataLength)
				RxHEXState=3;//转入模式3
		}
		else if(RxHEXState==3)//模式3-等待包尾
		{
			if(UART2_RxData==0x18)//检测包尾
			{
				Visual_Yaw=(int16_t)((uint16_t)Visual_RxHEXPacket[0]<<8 | Visual_RxHEXPacket[1])*0.01f;
				Visual_Pitch=(int16_t)((uint16_t)Visual_RxHEXPacket[2]<<8 | Visual_RxHEXPacket[3])*0.01f;
				Visual_ReceiveFlag=1;
			}
			RxHEXState=0;//回到模式0
		}
	}
	
	USART_ClearITPendingBit(USART1,USART_IT_RXNE);//清除接收中断标志位
}
