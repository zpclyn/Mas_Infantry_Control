#ifndef __TIM_H
#define __TIM_H

void TIM_Init(void);//TIM2定时器初始化

#endif
